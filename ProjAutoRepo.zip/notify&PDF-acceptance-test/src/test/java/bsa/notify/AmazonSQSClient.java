package bsa.notify;

import java.io.IOException;
import java.util.List;
import com.amazonaws.auth.DefaultAWSCredentialsProviderChain;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.sqs.AmazonSQSAsync;
import com.amazonaws.services.sqs.AmazonSQSAsyncClientBuilder;
import com.amazonaws.services.sqs.model.Message;
import com.amazonaws.services.sqs.model.PurgeQueueRequest;
import com.amazonaws.services.sqs.model.ReceiveMessageRequest;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;


public class AmazonSQSClient {
	
	public static final String DLQ_URL = PropertyReader.getProperty("dlq.url");

	public static boolean getMessage(String idempotencyKey) throws IOException 
	
	{
		System.out.println("URL for DLQ: "+DLQ_URL);
		AmazonSQSAsync amazonSQSAsync = AmazonSQSAsyncClientBuilder.standard().withRegion(Regions.EU_WEST_2).withCredentials(new DefaultAWSCredentialsProviderChain()).build();
		ReceiveMessageRequest receiveMessageRequest = new ReceiveMessageRequest(DLQ_URL);
		receiveMessageRequest.setMaxNumberOfMessages(10);
		receiveMessageRequest.setWaitTimeSeconds(20);
		List<Message> messages = null;
		boolean flag = true;
		boolean result = false;
		
		while(flag) 
		{
			messages = amazonSQSAsync.receiveMessage(receiveMessageRequest).getMessages();
			System.out.println("<--------------------- Messages size --------------------->");
			System.out.println("Currently available number of messages in DLQ for this iteration : " + messages.size());
			
			for (Message message : messages) 
				
			{

				ObjectReader reader = new ObjectMapper().readerFor(NotificationMessage.class);						    
				NotificationMessage notificationMessage = reader.readValue(message.getBody());

				System.out.println("<--------------------- Current message in DLQ --------------------->");
				System.out.println(message);
				System.out.println("<--------------------- Body of the current message --------------------->");
				System.out.println(message.getBody());				

				if(notificationMessage.getIdempotencyKey().equalsIgnoreCase(idempotencyKey))
				{
					result = notificationMessage.getIdempotencyKey().equalsIgnoreCase(idempotencyKey);
					System.out.println("Invalid message is present in DLQ");
					flag = false;
				}				
			}
		}
			return result;
	}
	
	public static boolean getMessageForBlankRequest(String payload) throws IOException 
	
	{
		System.out.println("DLQ URL: "+DLQ_URL);
		AmazonSQSAsync amazonSQSAsync = AmazonSQSAsyncClientBuilder.standard().withRegion(Regions.EU_WEST_2).withCredentials(new DefaultAWSCredentialsProviderChain()).build();
		ReceiveMessageRequest receiveMessageRequest = new ReceiveMessageRequest(DLQ_URL);
		receiveMessageRequest.setMaxNumberOfMessages(10);
		receiveMessageRequest.setWaitTimeSeconds(20);
		List<Message> messages = null;
		boolean flag = true;
		boolean result = false;
		
		while(flag) 
		{
			messages = amazonSQSAsync.receiveMessage(receiveMessageRequest).getMessages();
			System.out.println("<--------------------- Messages size --------------------->");
			System.out.println("Currently available number of messages in DLQ for this iteration : " + messages.size());
			
			for (Message message : messages) 
				
			{
				System.out.println("<--------------------- Current message in DLQ --------------------->");
				System.out.println(message);
				System.out.println("<--------------------- Body of the messagecurrent message --------------------->");
				System.out.println(message.getBody());				

				if(message.getBody().equals(payload)) 
				{					
					result = message.getBody().equals(payload);
					System.out.println("Invalid message is present in DLQ");
					flag = false;
				}
			}
		}
			return result;
	}

	public static void deleteMessage(String messageReceiptHandle) 
	
	{

		AmazonSQSAsync amazonSQSAsync = AmazonSQSAsyncClientBuilder.standard().withRegion(Regions.EU_WEST_2).withCredentials(new DefaultAWSCredentialsProviderChain()).build();
		amazonSQSAsync.deleteMessage(DLQ_URL,messageReceiptHandle);
	}

	public static void purgeQueue() 
		
	{

		AmazonSQSAsync amazonSQSAsync = AmazonSQSAsyncClientBuilder.standard().withRegion(Regions.EU_WEST_2).withCredentials(new DefaultAWSCredentialsProviderChain()).build();
		amazonSQSAsync.purgeQueue(new PurgeQueueRequest(DLQ_URL));

	}
	
}
