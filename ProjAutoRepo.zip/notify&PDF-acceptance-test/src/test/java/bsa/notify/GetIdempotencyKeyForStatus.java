package bsa.notify;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class GetIdempotencyKeyForStatus {

	public static final String DB_DRIVER = PropertyReader.getProperty("db.driver");
	public static final String DB_CONNECTION = PropertyReader.getProperty("db.connection");
	public static final String DB_USER = PropertyReader.getProperty("db.username");
	public static final String DB_PASSWORD = PropertyReader.getProperty("db.password");



	public static String getIdempotencyKeyFromDB(String status, String notificationType) throws SQLException, IOException {
		Connection dbConnection = null;	
		String idempotencykey = null;
		 
		try {
			dbConnection = getDBConnection();
			Statement statement = dbConnection.createStatement();			
			
			ResultSet resultSet = statement.executeQuery("SELECT * FROM bsa_notify_01.bsa_notify where status = '"+status+"' AND notification_type = '"+notificationType+"';");						
			while(resultSet.next()) {
			idempotencykey = resultSet.getString("idempotency_key");
			}
		
		}
		finally {

			if (dbConnection != null) {
				dbConnection.close();
			}

		}
		return idempotencykey;
	}
	
	public static Connection getDBConnection() {

		Connection dbConnection = null;

		try {

			Class.forName(DB_DRIVER);

		} catch (ClassNotFoundException e) {

			System.out.println(e.getMessage());

		}

		try {

			dbConnection = DriverManager.getConnection(DB_CONNECTION, DB_USER, DB_PASSWORD);
			return dbConnection;

		} catch (SQLException e) {

			System.out.println(e.getMessage());

		}

		return dbConnection;

	}
}
