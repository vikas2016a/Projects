package bsa.notify;


public class GetApiKey {

	public static final String CCE_APIKEY = PropertyReader.getProperty("cce.apikey");
	public static final String CCE1_APIKEY = PropertyReader.getProperty("cce1.apikey");
	public static final String OHS_APIKEY = PropertyReader.getProperty("ohs.apikey");
	public static final String PPC_APIKEY = PropertyReader.getProperty("ppc.apikey");
	public static final String SMSCC_APIKEY = PropertyReader.getProperty("smscc.apikey");
	
	public static String getApikeyForService(String service)
	{
		String apiKey = null;
		
		if (service.equals("CCE"))
			apiKey = CCE_APIKEY;
		
		else if (service.equals("CCE1"))
			apiKey = CCE1_APIKEY;
		
		else if (service.equals("OHS"))
			apiKey = OHS_APIKEY;
		
		else if (service.equals("PPC"))
			apiKey = PPC_APIKEY;
		
		else if (service.equals("SmsCC"))
			apiKey = SMSCC_APIKEY;
		
		else 
			apiKey = "Invalid service";
		
		return apiKey;	
		
	}
	



	
}
