package bsa.notify.mockServer;

import org.apache.http.client.fluent.Request;
import org.apache.http.entity.ContentType;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockserver.client.MockServerClient;
import org.mockserver.matchers.TimeToLive;
import org.mockserver.matchers.Times;
import org.mockserver.mock.Expectation;
import org.mockserver.model.Header;
import org.mockserver.model.HttpRequest;
import org.mockserver.model.SocketAddress;

import java.io.IOException;
import java.net.SocketTimeoutException;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockserver.model.HttpOverrideForwardedRequest.forwardOverriddenRequest;
import static org.mockserver.model.HttpRequest.request;
import static org.mockserver.model.HttpResponse.response;
import static org.mockserver.model.JsonBody.json;

public class Client {

    private final static String MOCK_HOST = System.getProperty("mockServer.url", "DPS-DEV-SHA-MOCSE-APP-01.node.nhsbsa");
    private final static int MOCK_PORT = Integer.parseInt(System.getProperty("mockServer.port", "1080"));
    private final static String MOCK_CONTEXT_PATH  = System.getProperty("mockServer.contextPath", "mockserver");
    private static final String GOV_NOTIFY_HOST = "api.notifications.service.gov.uk";

    public final static MockServerClient  mockServerClient = new MockServerClient(MOCK_HOST, MOCK_PORT);
    private final static String MOCK_SERVER_URL = "http://"+ mockServerClient.remoteAddress().getHostName()
            + ":" + mockServerClient.remoteAddress().getPort()
            + "/" + mockServerClient.contextPath();
    
    private static org.apache.http.HttpResponse httpResponse = null;


    @BeforeEach
    public static void setup() {
        mockServerClient.reset(); // Reset the existing expectations

        // Circuit Breaker - 500
        HttpRequest circuitBreaker500 = request()
                .withMethod("POST")
                .withPath("/v2/notifications/email")
                .withHeader(Header.header("Content-Type", "application/json"))
                .withBody(json("{" + "\"email_address\":\"joe.bloggs@nhs.net" + "\"," +
                        " \"template_id\":\"8728e248-7351-4885-9c49-554c8d01adf5" + "\"," +
                        " \"email_reply_to_id\":\"circuit.breaker500@nhs.net\"" +
                        "}")
                );
        mockServerClient.when(circuitBreaker500).respond(response().withStatusCode(500).
                withBody(json("{ \"error\": \"Response from Mock Server: Internal Server Error\"}")));

        // setup default expectation
        HttpRequest allRequests = request().withMethod("POST");
        mockServerClient
                .when(allRequests, Times.unlimited(), TimeToLive.unlimited(), -1)
                .forward(forwardOverriddenRequest(
                        request()
                                .withHeader("Host", GOV_NOTIFY_HOST)
                                .withSocketAddress(GOV_NOTIFY_HOST,443, SocketAddress.Scheme.HTTPS)
                ));
    }

    @Test
    public void tryMockExpectationEmailSuccess() throws Exception {
        String notificationId = UUID.randomUUID().toString();

        //Given
        HttpRequest mockHttpRequest = Util.successful(mockServerClient, "email", notificationId);

        //When - use a client to talk to our mock server expectation
        org.apache.http.HttpResponse httpResponse = Request.Post(MOCK_SERVER_URL + "/v2/notifications/email")
                .addHeader("Authorization", Util.GOV_NOTIFY_AUTHORIZATION_TOKEN)
                .addHeader("Content-Type", "application/json")
                .bodyString("{ \"email_address\":\"joe.bloggs@nhs.net\", \"template_id\":\"sdlkjflksdjfldsf\" }", ContentType.APPLICATION_JSON)
                .execute()
                .returnResponse();

        //Then - check client response and server expectation was called
        Assertions.assertEquals(201, httpResponse.getStatusLine().getStatusCode());
        Util.verify(mockServerClient, mockHttpRequest);
    }

    @Test
    public void tryMockExpectationInvalidAuthorization() throws Exception {
        //Given
        HttpRequest mockHttpRequest = Util.errorInvalidApiKey(mockServerClient, "email");

        //When - use a client to talk to our mock server expectation
        org.apache.http.HttpResponse httpResponse = Request.Post(MOCK_SERVER_URL + "/v2/notifications/email")
                .addHeader("Authorization", Util.GOV_NOTIFY_INVALID_TOKEN)
                .addHeader("Content-Type", "application/json")
                .bodyString("{ \"email_address\":\"joe.bloggs@nhs.net\", \"template_id\":\"sdlkjflksdjfldsf\" }", ContentType.APPLICATION_JSON)
                .execute()
                .returnResponse();

        //Then - check client response and server expectation was called
        Assertions.assertEquals(403, httpResponse.getStatusLine().getStatusCode());
        Util.verify(mockServerClient, mockHttpRequest);
    }

    @Test
    public void tryMockHttpTimeout() throws Exception {
        //Given
        Util.timeout(mockServerClient, "email");

        //When & Then - use a client to talk to our mock server expectation
        assertThrows(SocketTimeoutException.class, () -> {
            Request.Post(MOCK_SERVER_URL + "/v2/notifications/email")
                    .addHeader("Authorization", Util.GOV_NOTIFY_AUTHORIZATION_TOKEN)
                    .addHeader("Content-Type", "application/json")
                    .bodyString("{ \"email_address\":\"joe.bloggs@nhs.net\", \"template_id\":\"sdlkjflksdjfldsf\" }", ContentType.APPLICATION_JSON)
                    .connectTimeout(5000)
                    .socketTimeout(5000)
                    .execute()
                    .returnResponse();
        });
    }

    public static void main(String[] args) {
        mockServerClient.reset();
        String notificationId = UUID.randomUUID().toString();
        //Given
        HttpRequest httpSuccessfulRequest = Util.notificationSentSuccessfully("email", notificationId);
		HttpRequest httpTimeoutRequest = Util.mockServerDelay("email");

        //When - use a client to talk to our mock server expectation
        org.apache.http.HttpResponse httpResponse = null;
        try {
            httpResponse = Request.Post(MOCK_SERVER_URL + "/v2/notifications/email")
                    .addHeader("Authorization", Util.GOV_NOTIFY_AUTHORIZATION_TOKEN)
                    .bodyString("{\"email_address\":\"joe.bloggs@nhs.net\", \"template_id\":\"emailTestTemplate\", \"service_name\":\"CC\", \"service_reference\":\"successfulRequestReff\"}", ContentType.APPLICATION_JSON)
                    .execute()
                    .returnResponse();
        } catch (IOException e) {
            e.printStackTrace();
        }

        //Then - check client response and server expectation was called
        Assertions.assertEquals(200, httpResponse.getStatusLine().getStatusCode());
        System.out.println(httpResponse.getStatusLine().getReasonPhrase());
        Util.verify(mockServerClient, httpSuccessfulRequest);

        try {
            httpResponse = Request.Post(MOCK_SERVER_URL + "/v2/notifications/email")
                    .addHeader("Authorization", Util.GOV_NOTIFY_AUTHORIZATION_TOKEN)
                    .addHeader("Content-Type", "application/json")
                    .bodyString("{\"email_address\":\"joe.bloggs@nhs.net\", \"template_id\":\"mockServerDelayTemplate\", \"service_name\":\"mockServerDelayService\", \"service_reference\":\"mockServerDelayReff\"}", ContentType.APPLICATION_JSON)
                    .execute()
                    .returnResponse();
        } catch (IOException e) {
            e.printStackTrace();
        }
        Assertions.assertEquals(408, httpResponse.getStatusLine().getStatusCode());
        System.out.println(httpResponse.getStatusLine().getReasonPhrase());
        Util.verify(mockServerClient, httpTimeoutRequest);
    }

//    @Test
//    public void tryForwardEmailSuccess() throws Exception {
//        Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(MOCK_HOST, MOCK_PORT));
//
//        NotificationClient client = new NotificationClient("garyapi-3215f614-15dd-4da3-ac1d-f0de6c3f5a9c-afebdcd3-fd47-4f1e-a037-86dc18bcf774", proxy);
//        SendEmailResponse response = client.sendEmail("a54433ba-858a-45c7-a1c6-2f218dbfe2ef", "gary.brown3@nhs.net", null, null);
//
//        assertNotNull(response.getNotificationId());
//    }
    public static org.apache.http.HttpResponse sendRequestForSuccessfullNotification()
    {
    try {
        httpResponse = Request.Post(MOCK_SERVER_URL + "/v2/notifications/email")
                .addHeader("Authorization", Util.GOV_NOTIFY_AUTHORIZATION_TOKEN)
                .addHeader("Content-type", "application/json")
                .bodyString(Util.successfulRequestJson(), ContentType.APPLICATION_JSON)
                .execute()
                .returnResponse();
    } catch (IOException e) {
        e.printStackTrace();
    }
    return httpResponse;
    }
    
 public static boolean assertResponse(HttpRequest httpRequest, int status, org.apache.http.HttpResponse httpResponse )
    {
        System.out.println("url"+MOCK_SERVER_URL);
        boolean flag = false;
    	System.out.println("Expected Status: "+status);
    	System.out.println("Actual status: "+httpResponse.getStatusLine().getStatusCode());
    	System.out.println("Expected request: "+mockServerClient);
    	System.out.println("Actual request: "+httpRequest);
    	
    	if(status == httpResponse.getStatusLine().getStatusCode())
    	{
    	     Util.verify(mockServerClient, httpRequest);
    	     flag = true;
    	}
        //Assertions.assertEquals(status, httpResponse.getStatusLine().getStatusCode());
        System.out.println(httpResponse.getStatusLine().getReasonPhrase());
        //Util.verify(mockServerClient, httpRequest);
        return flag;
    }


}
