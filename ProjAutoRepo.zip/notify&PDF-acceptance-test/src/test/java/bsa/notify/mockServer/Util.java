package bsa.notify.mockServer;

import org.mockserver.client.MockServerClient;
import org.mockserver.model.HttpRequest;

import static org.mockserver.model.HttpRequest.request;
import static org.mockserver.model.HttpResponse.response;
import static org.mockserver.model.JsonBody.json;
import net.minidev.json.JSONObject;
import java.util.concurrent.TimeUnit;

import org.mockserver.model.Delay;
import org.mockserver.model.Header;
import org.mockserver.model.HttpResponse;

public class Util {

    public static final String GOV_NOTIFY_EXCEPTION_INVALID_APIKEY_MSG = "[{ \"error\": \"AuthError\", \"message\": \"Invalid token: API key not found\" }]";

    public static final String GOV_NOTIFY_INVALID_TOKEN = "<invalid token>";

    public static final String GOV_NOTIFY_AUTHORIZATION_TOKEN = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiIyNjc4NWEwOS1hYjE2LTRlYjAtODQwNy1hMzc0OTdhNTc1MDYiLCJpYXQiOjE1OTE0MzkwMjJ9.DxvTvfNXD_xXjGeiFhe2hqMWoI56-__WNAHW1GIBPSk";

    public static final String GOV_NOTIFY_BADREQUESTERROR = "BadRequestError";
    public static final String GOV_NOTIFY_AUTHERROR = "AuthError";
    public static final String GOV_NOTIFY_RATELIMITERROR = "RateLimitError";
    public static final String GOV_NOTIFY_TOOMANYREQUESTSERROR = "TooManyRequestsError";
    public static final String GOV_NOTIFY_EXCEPTION = "Exception";
    public static MockServerClient mockServerClient = Client.mockServerClient;
    
    //Setup for timeout exception
    public static HttpRequest mockServerDelay(String notificationType) {
        HttpRequest mockHttpRequest = mockServerDelayNotificationRequest(notificationType, GOV_NOTIFY_AUTHORIZATION_TOKEN);
        mockServerClient.when(mockHttpRequest).respond(mockServerDelayResponse());
        return mockHttpRequest;
    }
	
	private static HttpResponse mockServerDelayResponse() {
        return response()
                .withStatusCode(408)
                .withDelay(new Delay(TimeUnit.MINUTES, 2))
                .withBody(json("{ \"error\": \"timeOutException" + "\"," +
                        "\"message\": \"The client did not produce a request within the time that the server was prepared to wait\"}"));               
    }
	
	public static String moerverDelayNotificationJson()
	{
		JSONObject request = new JSONObject();
		request.put("emailAddress", "joe.bloggs@nhs.net");
		request.put("template_id", "mockServerDelayTemplate");
		request.put("service_name", "CC");
		request.put("service_reference", "mockServerDelayReff");
	    return request.toString();
	}
	
	 private static HttpRequest mockServerDelayNotificationRequest(String notificationType, String token) {
        return request()
                .withMethod("POST")
                .withPath("/v2/notifications/" + notificationType)
                .withHeader(Header.header("Content-Type", "application/json"))
                .withHeader(Header.header("Authorization", token))
                .withBody(moerverDelayNotificationJson());
    }
	 
	 // setup for successful request
	 public static HttpRequest notificationSentSuccessfully(String notificationType, String notificationId) {
	        System.out.println("Test Started");
	        HttpRequest mockHttpRequest = notificationSentSuccessfullyRequest(notificationType, GOV_NOTIFY_AUTHORIZATION_TOKEN);
	        System.out.println("Request is setup "+mockHttpRequest);
	        mockServerClient.when(mockHttpRequest).respond(notificationSentSuccessfullyResponse(notificationId));
	        return mockHttpRequest;
	    }
		
		private static HttpResponse notificationSentSuccessfullyResponse(String notificationId) {
	        return response()
	                .withStatusCode(200)
	                .withHeader(Header.header("Content-Type", "application/json"))
	                .withBody(json("\"notification_id\": " + notificationId + "\"," +
	                        "  \"service_reference\": \"successfulRequestReff" + "\"," +
	                        "  \"uri\": \"https://api.notifications.service.gov.uk/v2/notifications/" + notificationId + "\"," +
	                        "  \"service_name\": \"CC " + "\"," +
							"  \"template_id\": \"emailTestTemplate " + "\"," +
							"  \"message\": \"Successful\"" +
	                        "}")
	                );
	    }
		
		public static String successfulRequestJson()
		{
			JSONObject request = new JSONObject();
			request.put("emailAddress", "joe.bloggs@nhs.net");
			request.put("template_id", "emailTestTemplate");
			request.put("service_name", "CC");
			request.put("service_reference", "successfulRequestReff");
		    return request.toString();
		}
		
		 private static HttpRequest notificationSentSuccessfullyRequest(String notificationType, String token) {
		        return request()
		                .withMethod("POST")
		                .withPath("/v2/notifications/" + notificationType)
		                .withHeader(Header.header("Content-Type", "application/json"))
		                .withHeader(Header.header("Authorization", token))
		                .withBody(successfulRequestJson());
		 }
		 
		 // setup for rate limit error
		 public static HttpRequest notificationSentWithRateLimitError(String notificationType) {
		        HttpRequest mockHttpRequest = notificationSentWithRateLimitErrorRequest(notificationType, GOV_NOTIFY_AUTHORIZATION_TOKEN);
		        mockServerClient.when(mockHttpRequest).respond(notificationSentWithRateLimitErrorResponse());
		        return mockHttpRequest;
		    }
			
			private static HttpResponse notificationSentWithRateLimitErrorResponse() {
		        return response()
		                .withStatusCode(429)
		                .withHeader(Header.header("Content-Type", "application/json"))
		                .withBody(json("{ \"error\": \"tooManyRequestsException" + "\"," +
		                        "\"message\": \"The user has sent too many requests in a given amount of time\"}"));
		    }
			
			public static String rateLimitErrorJson()
			{
				JSONObject request = new JSONObject();
				request.put("emailAddress", "joe.bloggs@nhs.net");
				request.put("template_id", "emailTestTemplate");
				request.put("service_name", "CC");
				request.put("service_reference", "raleLimitErrorRef");
			    return request.toString();
			}
			
			
			 private static HttpRequest notificationSentWithRateLimitErrorRequest(String notificationType, String token) {
			        return request()
			                .withMethod("POST")
			                .withPath("/v2/notifications/" + notificationType)
			                .withHeader(Header.header("Content-Type", "application/json"))
			                .withHeader(Header.header("Authorization", token))
			                .withBody(rateLimitErrorJson());							
			    }
			 
			// setup for invalid Gov Notify.UK token
			 public static HttpRequest notificationSendWithInvalidGovNotifyToken(String notificationType) {
			        System.out.println("Test Started");
			        HttpRequest mockHttpRequest = notificationSendWithInvalidGovNotifyTokenRequest(notificationType, GOV_NOTIFY_INVALID_TOKEN);
			        System.out.println("Request is setup "+mockHttpRequest);
			        mockServerClient.when(mockHttpRequest).respond(notificationSendWithInvalidGovNotifyTokenResponse());
			        return mockHttpRequest;
			    }
				
				private static HttpResponse notificationSendWithInvalidGovNotifyTokenResponse() {
			        return response()
			                .withStatusCode(403)
			                .withHeader(Header.header("Content-Type", "application/json"))
			                .withBody(json("{ \"error\": \"AuthError" + "\"," +
			                        "\"message\": \"Invalid token: API key not found\"}"));
			    }
				
				public static String invalidTokenJson()
				{
					JSONObject request = new JSONObject();
					request.put("emailAddress", "joe.bloggs@nhs.net");
					request.put("template_id", "emailTestTemplate");
					request.put("service_name", "CC");
					request.put("service_reference", "invalidTokenReff");
				    return request.toString();
				}
				
				 private static HttpRequest notificationSendWithInvalidGovNotifyTokenRequest(String notificationType, String token) {
				        return request()
				                .withMethod("POST")
				                .withPath("/v2/notifications/" + notificationType)
				                .withHeader(Header.header("Content-Type", "application/json"))
				                .withHeader(Header.header("Authorization", token))
				                .withBody(invalidTokenJson());
				    }
				 
				 // setup for system clock error
				 public static HttpRequest notificationSentWithSystemClockError(String notificationType) {
				        System.out.println("Test Started");
				        HttpRequest mockHttpRequest = notificationSentWithSystemClockErrorRequest(notificationType, GOV_NOTIFY_AUTHORIZATION_TOKEN);
				        System.out.println("Request is setup "+mockHttpRequest);
				        mockServerClient.when(mockHttpRequest).respond(notificationSentWithSystemClockResponse());
				        return mockHttpRequest;
				    }
					
					private static HttpResponse notificationSentWithSystemClockResponse() {
				        return response()
				                .withStatusCode(403)
				                .withHeader(Header.header("Content-Type", "application/json"))
				                .withBody(json("{ \"error\": \"AuthError" + "\"," +
				                        "\"message\": \"Your system clock must be accurate to within 30 seconds\"}"));
				    }
					
					public static String systemClockErrorJson()
					{
						JSONObject request = new JSONObject();
						request.put("emailAddress", "joe.bloggs@nhs.net");
						request.put("template_id", "emailTestTemplate");
						request.put("service_name", "CC");
						request.put("service_reference", "systemClockErrorReff");
					    return request.toString();
					}
					
					
					 private static HttpRequest notificationSentWithSystemClockErrorRequest(String notificationType, String token) {
					        return request()
					                .withMethod("POST")
					                .withPath("/v2/notifications/" + notificationType)
					                .withHeader(Header.header("Content-Type", "application/json"))
					                .withHeader(Header.header("Authorization", token))
					                .withBody(systemClockErrorJson());							
					    }
					 
					 	 // setup for internal server error
				 public static HttpRequest notificationSentWithInternalServerError(String notificationType) {
				        System.out.println("Test Started");
				        HttpRequest mockHttpRequest = notificationSentWithInternalServerErrorRequest(notificationType, GOV_NOTIFY_AUTHORIZATION_TOKEN);
				        System.out.println("Request is setup "+mockHttpRequest);
				        mockServerClient.when(mockHttpRequest).respond(notificationSentWithinternalServerErrorResponse());
				        return mockHttpRequest;
				    }
					
					private static HttpResponse notificationSentWithinternalServerErrorResponse() {
				        return response()
				                .withStatusCode(500)
				                .withHeader(Header.header("Content-Type", "application/json"))
				                .withBody(json("{ \"error\": \"Exception" + "\"," +
				                        "\"message\": \"Internal server error\"}"));
				    }
					
					public static String ineternalServerErrorJson()
					{
						JSONObject request = new JSONObject();
						request.put("emailAddress", "joe.bloggs@nhs.net");
						request.put("template_id", "emailTestTemplate");
						request.put("service_name", "CC");
						request.put("service_reference", "internalServerErrorReff");
					    return request.toString();
					}
					
					
					 private static HttpRequest notificationSentWithInternalServerErrorRequest(String notificationType, String token) {
					        return request()
					                .withMethod("POST")
					                .withPath("/v2/notifications/" + notificationType)
					                .withHeader(Header.header("Content-Type", "application/json"))
					                .withHeader(Header.header("Authorization", token))
					                .withBody(ineternalServerErrorJson());							
					    }
					 //
			

    public static HttpRequest errorInvalidApiKey(MockServerClient mockServerClient, String notificationType) {
        HttpRequest mockHttpRequest = mockSendNotificationRequest(notificationType, GOV_NOTIFY_INVALID_TOKEN);

        mockServerClient.when(mockHttpRequest)
                .respond(mockSendNotificationErrorResponse(403,
                        GOV_NOTIFY_AUTHERROR, GOV_NOTIFY_EXCEPTION_INVALID_APIKEY_MSG));

        return mockHttpRequest;
    }



    public static HttpRequest successful(MockServerClient mockServerClient, String notificationType, String notificationId) {
        HttpRequest mockHttpRequest = mockSendNotificationRequest(notificationType, GOV_NOTIFY_AUTHORIZATION_TOKEN);
        mockServerClient.when(mockHttpRequest).respond(mockSendRateLimitErrorResponse(notificationId));
        return mockHttpRequest;
    }


    public static HttpRequest timeout(MockServerClient mockServerClient, String notificationType) {
        HttpRequest mockHttpRequest = mockSendNotificationRequest(notificationType, GOV_NOTIFY_AUTHORIZATION_TOKEN);
        mockServerClient.when(mockHttpRequest).respond(mockTimeout());
        return mockHttpRequest;
    }

    public static void verify(MockServerClient mockServerClient, HttpRequest httpRequest) {
        mockServerClient.verify(httpRequest);
    }

    private static HttpResponse mockSendNotificationErrorResponse(int code, String errorTitle, String msg) {
        return response()
                .withStatusCode(code)
                .withBody(json("\"errors\": [{" +
                        "\"error\": \"" + errorTitle + "\"" +
                        "\"message\": \"" + msg + "\"" +
                        "}]")
                );
    }


    private static HttpResponse mockTimeout() {
        return response()
                .withStatusCode(201)
                .withDelay(new Delay(TimeUnit.MINUTES, 2))
                .withBody(json("\"id\": null," +
                        "  \"reference\": null," +
                        "  \"scheduled_for\": null," +
                        "  \"content\": null, " +
                        "  \"uri\": null," +
                        "  \"template\": null" +
                        "}")
                );
    }

    private static HttpResponse mockSendNotificationResponse(String notificationId) {
        return response()
                .withStatusCode(201)
                .withBody(json("\"id\": " + notificationId + "," +
                        "  \"reference\": null," +
                        "  \"scheduled_for\": null," +
                        "  \"content\": null, " +
                        "  \"uri\": \"https://api.notifications.service.gov.uk/v2/notifications/" + notificationId + "\"," +
                        "  \"template\": null" +
                        "}")
                );
    }

    private static HttpResponse mockSendRateLimitErrorResponse(String notificationId) {
        return response()
                .withStatusCode(429)
                .withBody(json("{ \"error\": \"RateLimitError\", " +
                        "\"message\": \"Exceeded rate limit for key type " +
                        "TEAM/TEST/LIVE of 3000 requests per 60 seconds\"}"));
    }

    private static HttpResponse mock500ErrorResponse() {
        return response()
                .withStatusCode(500)
                .withBody(json("{ \"error\": \"RateLimitError\", " +
                        "\"message\": \"Internal Server Error\"}"));
    }

    private static HttpRequest mockSendNotificationRequest(String notificationType, String token) {
        return request()
                .withMethod("POST")
                .withPath("/v2/notifications/" + notificationType)
                .withHeader(Header.header("Content-Type", "application/json"))
                .withHeader(Header.header("Authorization", token))
                .withBody("{ \"email_address\":\"joe.bloggs@nhs.net\", \"template_id\":\"TOO-MANY-REQUESTS\" }");
    }

    private static HttpRequest mock500NotificationRequest(String notificationType, String token) {
        return request()
                .withMethod("POST")
                .withPath("/v2/notifications/" + notificationType)
                .withHeader(Header.header("Content-Type", "application/json"))
                .withHeader(Header.header("Authorization", token))
                .withBody("{ \"email_address\":\"joe.bloggs@nhs.net\", \"template_id\":\"500-REQUEST\" }");
    }

    public static HttpRequest mock500(MockServerClient mockServerClient, String notificationType, String notificationId) {
        HttpRequest mockHttpRequest = mock500NotificationRequest(notificationType, GOV_NOTIFY_AUTHORIZATION_TOKEN);
        mockServerClient.when(mockHttpRequest).respond(mock500ErrorResponse());
        return mockHttpRequest;
    }
}
