package bsa.notify;

import java.util.UUID;  

public class CreateIdempotencyKey
{
	
	public static String getIdempotencyKey()
	{
		String idempotencyKey=UUID.randomUUID().toString(); //Generates random UUID
		return idempotencyKey;		
	}
} 
