package bsa.notify.pdfGeneration.utilities;

import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.io.File;


public class ByteArrayToPdf 
{
	public static File getGeneratedFilePath(String scenario)
	{
		String filePath = "src\\test\\java\\bsa\\notify\\pdfGeneration\\generatedPdf\\";
		String fileExtension = ".pdf";
		DateFormat df = new SimpleDateFormat("yyyyMMddhhmmss"); 
		String filename = filePath + scenario + df.format(new Date()) + "." + fileExtension;
		File file = new File(filename);
		return file;
	}
	
	public static boolean convertByteArrayToPdf(File generatedFile, byte [] byteStream) throws IOException 
	{    
		File file = generatedFile;
        FileOutputStream fileOutputStream = new FileOutputStream(file);
        fileOutputStream.write(byteStream);
        fileOutputStream.flush();
        fileOutputStream.close();
        return true;
	}
}