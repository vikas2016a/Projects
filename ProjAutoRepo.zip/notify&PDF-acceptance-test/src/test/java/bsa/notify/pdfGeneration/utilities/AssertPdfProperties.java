package bsa.notify.pdfGeneration.utilities;

import java.io.*;
import static org.junit.Assert.*;	
import org.apache.pdfbox.cos.COSName;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDResources;
import org.apache.pdfbox.pdmodel.font.PDFont;
import java.util.ArrayList;
import java.util.Calendar;


public class AssertPdfProperties {
	
	public static boolean matchFileProperties (File generatedFile, byte [] byteStreamPDF) throws IOException
	{		
        PDDocument pdfDocument = PDDocument.load(generatedFile);
		PDDocument streamDocument = PDDocument.load(byteStreamPDF);
		ArrayList<Object> pdfDocumentFonts = new ArrayList<Object>();
		ArrayList<Object> streamDocumentFonts = new ArrayList<Object>();
		
		// Assert total number of pages	
		int countPDFPages = pdfDocument.getNumberOfPages();
		int countStreamPages = streamDocument.getNumberOfPages();
		System.out.println("Number of pages in PDF document " + countPDFPages );
		System.out.println("Number of pages in stream document " + countStreamPages);
		assertEquals(countPDFPages, countStreamPages);
		
		// Assert document Version		
		float pdfVersion = pdfDocument.getDocument().getVersion();
		float streamVersion = streamDocument.getDocument().getVersion();
		System.out.println("Version of PDF document " + pdfVersion);
		System.out.println("Version of stream document " + streamVersion);
		assertEquals(pdfVersion, streamVersion, 0.00);
		
		// Assert document Title		
		String pdfTitle = pdfDocument.getDocumentInformation().getTitle();
		String streamTitle = streamDocument.getDocumentInformation().getTitle();
		System.out.println("Title of PDF document " + pdfTitle);
		System.out.println("Title of stream document " + streamTitle);
		assertEquals(pdfTitle, streamTitle);
		
		// Assert document Author		
		String pdfAuthor = pdfDocument.getDocumentInformation().getAuthor();
		String streamAuthor = streamDocument.getDocumentInformation().getAuthor();
		System.out.println("Author of PDF document " + pdfAuthor);
		System.out.println("Author of stream document " + streamAuthor);
		assertEquals(pdfAuthor, streamAuthor);
		
		// Assert document Subject		
		String pdfSubject = pdfDocument.getDocumentInformation().getSubject();
		String streamSubject = streamDocument.getDocumentInformation().getSubject();
		System.out.println("Subject of PDF document " + pdfSubject);
		System.out.println("Subject of stream document " + streamSubject);
		assertEquals(pdfSubject, streamSubject);
		
		// Assert document Keywords		
		String pdfKeywords = pdfDocument.getDocumentInformation().getKeywords();
		String streamKeywords = streamDocument.getDocumentInformation().getKeywords();
		System.out.println("Keywords of PDF document " + pdfKeywords);
		System.out.println("Keywords of stream document " + streamKeywords);
		assertEquals(pdfKeywords, streamKeywords);
		
		// Assert document Producer		
		String pdfProducer = pdfDocument.getDocumentInformation().getProducer();
		assertEquals(pdfProducer, "NHS Business Services Authority");
		String streamProducer = streamDocument.getDocumentInformation().getProducer();
		System.out.println("Producer of PDF document " + pdfProducer);
		System.out.println("Producer of stream document " + streamProducer);
		assertEquals(pdfProducer, streamProducer);
		
		// Assert document Creation Date		
		Calendar pdfCreationDate = pdfDocument.getDocumentInformation().getCreationDate();
		Calendar streamCreationDate = streamDocument.getDocumentInformation().getCreationDate();
		System.out.println("Creation Date of PDF document " + pdfCreationDate);
		System.out.println("Creation Date of stream document " + streamCreationDate);
		assertEquals(pdfCreationDate, streamCreationDate);
		
		// Assert document fonts
		for (int i = 0; i < pdfDocument.getNumberOfPages(); ++i)
        {
            PDPage pdfPage = pdfDocument.getPage(i);
            PDResources pdfResources = pdfPage.getResources();
            for (COSName pdfFontName : pdfResources.getFontNames())
            {
                PDFont pdfFont = pdfResources.getFont(pdfFontName);
                pdfDocumentFonts.add(pdfFont);
            }
        }
		
		for (int i = 0; i < streamDocument.getNumberOfPages(); ++i)
		{
		    PDPage streamPage = streamDocument.getPage(i);
		    PDResources streamResources = streamPage.getResources();
		    for (COSName streamFontName : streamResources.getFontNames())
		    {
		    	PDFont streamFont = streamResources.getFont(streamFontName);
		    	streamDocumentFonts.add(streamFont);
		    }
        } 
		
		System.out.println("Following are the fonts present in PDF document: " + pdfDocumentFonts);
		System.out.println("Following are the fonts present in stream document: " + streamDocumentFonts);
		assertTrue(pdfDocumentFonts.toString().contentEquals(streamDocumentFonts.toString()));
		System.out.println("Fonts matched. "+pdfDocumentFonts.toString().contentEquals(streamDocumentFonts.toString()));
		
		return true;
	}
	
	public static boolean matchFileProperties (File generatedFile, String font1, String font2) throws IOException
	{
		PDDocument pdfDocument = PDDocument.load(generatedFile);
		ArrayList<Object> pdfDocumentFonts = new ArrayList<Object>();

		for (int i = 0; i < pdfDocument.getNumberOfPages(); ++i)
        {
            PDPage pdfPage = pdfDocument.getPage(i);
            PDResources pdfResources = pdfPage.getResources();
            for (COSName pdfFontName : pdfResources.getFontNames())
            {
                PDFont pdfFont = pdfResources.getFont(pdfFontName);
                pdfDocumentFonts.add(pdfFont);
            }
        }
		
		System.out.println("Font are: "+pdfDocumentFonts);
		
		assertTrue(pdfDocumentFonts.toString().contains(font1));
		assertTrue(pdfDocumentFonts.toString().contains(font2));		
		return true;
	}
}