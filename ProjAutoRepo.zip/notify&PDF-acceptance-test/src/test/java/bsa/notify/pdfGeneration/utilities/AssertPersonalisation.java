package bsa.notify.pdfGeneration.utilities;

import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;

public class AssertPersonalisation {

	public static boolean matchPersonalisation (File GeneratedPDF, String pers1,String pers2,String pers3,String pers4,String pers5,String pers6,String pers7,String pers8,String pers9,String pers10) throws IOException
	{		
		PDDocument document;
		File file = GeneratedPDF;
		document = PDDocument.load(file);
		String pdfText = new PDFTextStripper().getText(document);
		/*
		 * System.out.println( pers1 +" " + pers2+ " " + pers3+ " " + pers4+ " " +
		 * pers5+ " " + pers6+ " " + pers7+ " " + pers8+ " " + pers9+ " " + pers10);
		 * System.out.println("In personalisation assert1");
		 * System.out.println(pdfText);
		 */

		assertTrue(pdfText.contains(pers1));			
		assertTrue(pdfText.contains(pers2));		
		assertTrue(pdfText.contains(pers3));
		assertTrue(pdfText.contains(pers4));		
		assertTrue(pdfText.contains(pers5));		
		assertTrue(pdfText.contains(pers6));		
		assertTrue(pdfText.contains(pers7));		
		assertTrue(pdfText.contains(pers8));		
		assertTrue(pdfText.contains(pers9));		
		assertTrue(pdfText.contains(pers10));
		return true;
		}
	
	public static boolean matchPersonalisation (File GeneratedPDF, String pers1,String pers2,String pers3,String pers4) throws IOException
	{		
		PDDocument document;
		File file = GeneratedPDF;
		document = PDDocument.load(file);
		String pdfText = new PDFTextStripper().getText(document);
		
		  System.out.println( pers1 +" " + pers2+ " " + pers3+ " " + pers4);
		  System.out.println("In personalisation assert1");
		  System.out.println(pdfText);
		 

		assertTrue(pdfText.contains(pers1));			
		assertTrue(pdfText.contains(pers2));		
		assertTrue(pdfText.contains(pers3));
		assertTrue(pdfText.contains(pers4));		
		
		return true;
		}
	public static boolean matchPersonalisation (File GeneratedPDF, String pers1,String pers2,String pers3,String pers4,String pers5,String pers6,String pers7,String pers8) throws IOException
	{		
		PDDocument document;
		File file = GeneratedPDF;
		document = PDDocument.load(file);
		String pdfText = new PDFTextStripper().getText(document);

		assertTrue(pdfText.contains(pers1));	
		System.out.println(pers1);
		assertTrue(pdfText.contains(pers2));
		System.out.println(pers2);
		assertTrue(pdfText.contains(pers3));
		System.out.println(pers3);
		assertTrue(pdfText.contains(pers4));	
		System.out.println(pers4);
		assertTrue(pdfText.contains(pers5));	
		System.out.println(pers5);
		assertTrue(pdfText.contains(pers6));	
		System.out.println(pers6);
		assertTrue(pdfText.contains(pers7));
		System.out.println(pers7);
		assertTrue(pdfText.contains(pers8));
		System.out.println(pers8);

		return true;
		}
}