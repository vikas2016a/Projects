function() {
  var env = karate.env; // get system property 'karate.env'
  karate.log('karate.env system property was:', env);
  if (!env) {
    env = 'dev';
  }
  var config = {
    env: env
  }
  
  if (env == 'local') {
      config.notifyAPIBaseUrl = 'http://localhost:8080/v2/notifications';
	  config.pdfAPIBaseUrl = 'http://localhost:8080/v2/notifications';
	  config.apiKey = '';
	  config.delaySeconds = 120000;
  } 
  
  else if (env == 'dev') {
      config.notifyAPIBaseUrl = 'https://fh20ib91kh.execute-api.eu-west-2.amazonaws.com/DPS-DEV-NTF-STAGE';
	  config.pdfAPIBaseUrl = 'https://fh20ib91kh.execute-api.eu-west-2.amazonaws.com/DPS-DEV-NTF-STAGE';
	  config.apiKey = 'jOw2CJOUMm78u9cgGjIds49VBoMt9FGg2U9ddTg1';
	  config.delaySeconds = 120000;
  } 
  
  else if (env == 'tst') {
	    config.notifyAPIBaseUrl = 'https://l7mdj6dzr2.execute-api.eu-west-2.amazonaws.com/DPS-TST-NTF-STAGE/notifications';
		config.pdfAPIBaseUrl = 'https://l7mdj6dzr2.execute-api.eu-west-2.amazonaws.com/DPS-TST-NTF-STAGE/notifications';
		config.apiKey = 'TMUz1t6z3N15SY4Egs1Cc8kab5Frs8IC8ZZhMdwJ';
		config.delaySeconds = 120000;
  } 
  
  else if (env == 'stg') {
	    config.notifyAPIBaseUrl = 'http://stg-bsa-notify.service.nhsbsa:8080/v2/notifications';
		config.pdfAPIBaseUrl = '';
		config.apiKey = '';
		config.delaySeconds = 120000;
  } 
  
  else if (env == 'pro') {
	    config.notifyAPIBaseUrl = 'http://pro-bsa-notify.service.nhsbsa:8080/v2/notifications';
		config.pdfAPIBaseUrl = 'https://xuikpotwxj.execute-api.eu-west-2.amazonaws.com/PPS-PRO-NTF-STAGE/notifications';
		config.apiKey = 'UNEKXTgxkM4exUehuoP4Q1TJhQ8m6wDraTqqk2zr';
		config.delaySeconds = 120000;
  }
  karate.configure('connectTimeout', 5000);
  karate.configure('readTimeout', 5000);
  return config;
}





