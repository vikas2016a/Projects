# BSA Notify API tests
Note: In absence of dev/test if you want to run it locally you need to clone/copy the development code and make it running-

## Description

## Setup

* Maven should be installed
* clone/copy project
* To run it locally: first clone/copy all development project  and run it


## Running tests

* cd to project folder

For 'local' tests
* run `mvn clean test -Dkarate.env="local"`

For ALL Notify email features tests
* run `mvn clean test -Dkarate.env="local" -Dcucumber.options=" --tags @EmailNotify"`

For ALL PDF Generation features tests
* run `mvn clean test -Dkarate.env="tst" -Dcucumber.options=" --tags @pdf"`


To run the performance tests
* run `mvn clean test-compile gatling:test -Dkarate.env="local" -Dgatling.simulationClass=className.PerformanceRunner`
