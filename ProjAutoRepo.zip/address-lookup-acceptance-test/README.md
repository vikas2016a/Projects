# bsa-address-lookup-acceptance-test
Note: In absence of dev/test if you want to run it locally you need to clone/copy the development code and make it running-

# Parameter Information
1. Postcode - Manatory 
2. Start - Optional
3. Limit - Optional
4. Building Number - Optional

# Parameter Definition
1. Start - Represents page number
2. Limit - Represents number of addresses in response (Default limit = 200 and Maximum = 500)

## Description

## Setup

* Maven should be installed
* clone/copy project
* To run it locally: first clone/copy all development project  and run it


## Running tests

* cd to project folder

For Full test of Address Lookup Service on local environment
* run `mvn clean test -Dkarate.env="local"`

For Regression test of Address Lookup Service on test environment
* run `mvn clean test -Dkarate.env="tst" -Dcucumber.options=" --tags @addressLookup"`

For Smoke test of Address Lookup Service on test environment
* run `mvn clean test -Dkarate.env="tst" -Dcucumber.options=" --tags @smokeTest"`




