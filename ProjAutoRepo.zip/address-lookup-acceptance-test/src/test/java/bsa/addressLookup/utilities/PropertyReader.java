package bsa.addressLookup.utilities;

import org.apache.commons.io.IOUtils;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Properties;

public class PropertyReader {

    public static String getProperty(final String key) {
        Reader reader;
        InputStream targetStream;
        Properties properties = new Properties();
        // Need to add respective environments.
        String env = System.getProperty("karate.env");

        String scriptFilePath = "src/test/resources/databaseProperties/" + env + ".properties";

        try {
            reader = new BufferedReader(new FileReader(scriptFilePath));

            targetStream = IOUtils.toInputStream(IOUtils.toString(reader), StandardCharsets.UTF_8);
            properties.load(targetStream);

            reader.close();
            targetStream.close();
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }

        return properties.getProperty(key);
    }
}
