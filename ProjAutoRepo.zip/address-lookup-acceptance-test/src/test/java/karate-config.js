function() {
  var env = karate.env; 
  karate.log('karate.env system property was:', env);
  if (!env) {
    env = 'tst';
  }     
  var config = {
    env: env
  }
  if (env == 'local') {

      config.addressLookupUrl = 'http://localhost:8080/v1/address-lookup/addresses';
      config.apiKey = '';

  } else if (env == 'dev') {

      config.addressLookupUrl = 'https://mluxpzi6uk.execute-api.eu-west-2.amazonaws.com/DPS-DEV-ADD-STAGE/addresses';
      config.apiKey = '';

  } else if (env == 'tst') {
  	  
  	 config.addressLookupUrl = 'https://tst.services.nhsbsa.nhs.uk/v1/address-lookup/addresses';
	 config.apiKey = 'nr6D2dByrw8XIuvmZD9O9XcDCmtgHvq6LQyySJl6';
	 config.sslFlag = true
	  	  
  } else if (env == 'stg') {

	  config.addressLookupUrl = 'https://fjgcvvzbu1.execute-api.eu-west-2.amazonaws.com/PPS-STG-ADD-STAGE/addresses';
	  config.apiKey = 'We8x30af766MGhfU5Map07O1SvKo6xUQ3G4obpa6';
	  
  }  else if (env == 'pro') {

	  config.addressLookupUrl = 'https://rub4wxl7w2.execute-api.eu-west-2.amazonaws.com/PPS-PRO-ADD-STAGE/addresses';
	  config.apiKey = 'bmj0Si2WEc19E4n2Q2loy8uNTHYENhmv8am2WVxd';
  } 
  

  karate.configure('connectTimeout', 5000);
  karate.configure('readTimeout', 5000);
  return config;
}
