package bsaFileService;

import java.util.Date;
import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;

public class JwtTokenCreator 
{	
	public static String createJwtToken(String secretKeyString, String serviceCode) 
	{		
		Algorithm algorithm = Algorithm.HMAC256(secretKeyString);
		Date now = new Date(System.currentTimeMillis());
		String token = JWT.create().withIssuedAt(now).withIssuer(serviceCode).sign(algorithm);
		return token;
	}
}