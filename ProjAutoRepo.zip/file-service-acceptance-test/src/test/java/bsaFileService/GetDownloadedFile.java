package bsaFileService;

import java.io.File;

import java.util.HashMap;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.github.bonigarcia.wdm.WebDriverManager;


public class GetDownloadedFile {
	
	public static String downloadPath = "\\src\\test\\java\\externalFiles\\downloadedFiles";
	
	
	public static void verifyFileDownloaded(String URL, String fileName, String fileExtension) throws Exception
	{
		WebDriverManager.chromedriver().setup();
		HashMap<String, Object> chromePrefs = new HashMap<String, Object>();
		chromePrefs.put("profile.default_content_settings.popups", 0);
		chromePrefs.put("download.default_directory", downloadPath);
		ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("prefs", chromePrefs);
		DesiredCapabilities cap = DesiredCapabilities.chrome();
		cap.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		cap.setCapability(ChromeOptions.CAPABILITY, options);
		WebDriver driver = new ChromeDriver(cap);
		driver.manage().window().maximize();
		driver.get(URL);
		Thread.sleep(5000);
		//boolean flag2 = isFileDownloaded_Ext(downloadPath, fileExtension);
	    //Assert.assertTrue("Failed to download Expected document", isFileDownloaded(downloadPath, fileName));
	    //Assert.assertTrue("Failed to download document which has given extension", isFileDownloaded_Ext(fileExtension));
	    driver.quit();
	    
	}	

	public static boolean isFileDownloaded(String downloadPath, String fileName) 
	{
		boolean flag = false;
	    File dir = new File(downloadPath);
	    File[] dir_contents = dir.listFiles();
	  	    
	    for (int i = 0; i < dir_contents.length; i++) {
	        if (dir_contents[i].getName().equals(fileName))
	            return flag=true;
	            }

	    return flag;
	}
	    
	public static boolean isFileDownloaded_Ext(String fileExtension) 
	{
			boolean flag=false;
		    File dir = new File(downloadPath);
		    File[] files = dir.listFiles();
		    if (files == null || files.length == 0) {
		        flag = false;
		    }
		    
		    for (int i = 1; i < files.length; i++) {
		    	if(files[i].getName().contains(fileExtension)) {
		    		flag=true;
		    	}
		    }
		    return flag;
	}
}