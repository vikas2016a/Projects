package bsaFileService;

import org.apache.commons.lang.RandomStringUtils;

public class GetServiceModuleName {
	
	public static String getRandomString()
	{

         String res = RandomStringUtils.randomAlphanumeric(6);
	     
         int randomNumber = (int)(Math.random() * 50 + 1);
	     
	     String randomString = randomNumber+res;
		 return randomString;		
	}
	
	public static String getServiceModuleName()
	{
		String serviceModule = "CCMOD"+getRandomString();
		return serviceModule;
		
	}
	
	

}
