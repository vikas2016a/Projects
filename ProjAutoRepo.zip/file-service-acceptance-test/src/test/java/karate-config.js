function() {
  var env = karate.env; 
  karate.log('karate.env system property was:', env);
  if (!env) {
    env = 'tst';
  }     
  var config = {
    env: env
  }
  if (env == 'local') {

      config.fileServiceUrl = 'http://ec2-18-130-208-205.eu-west-2.compute.amazonaws.com:8080/v1/file-service/';
      config.bucketName = 'nhsbsa-local-fs-fileservice';
      config.apiKey = '';

  } else if (env == 'dev') {

      config.fileServiceUrl = 'https://h54yd79q38.execute-api.eu-west-2.amazonaws.com/DPS-DEV-FS-STAGE';
      config.bucketName = 'nhsbsa-dev-fs-fileservice';
      config.apiKey = '0tlNgcttM55lvwNCiDU1IacEzKZMUccFrfiOc7Yb';   

  } else if (env == 'tst') {

	  config.fileServiceUrl = 'https://ue4dd9rhv2.execute-api.eu-west-2.amazonaws.com/DPS-TST-FS-STAGE';
	  config.bucketName = 'nhsbsa-tst-fs-fileservice';
      config.apiKey = 'TzmXdiSaov4I5SCq2Wo3M7lLgaaqnmH5RNtId0g5';
	  
  } else if (env == 'stg') {

	  config.fileServiceUrl = 'https://lofbhw6gc4.execute-api.eu-west-2.amazonaws.com/PPS-STG-FS-STAGE';
	  config.bucketName = 'nhsbsa-stg-fs-fileservice';
      config.apiKey = 'ux7FYy7ThM5X8pgTZK6zqaoLYm3g7ZK9jnGOAtAd';
	  
  } else if (env == 'pro') {

	  config.fileServiceUrl = 'https://kgti4bctze.execute-api.eu-west-2.amazonaws.com/PPS-PRO-FS-STAGE';
	  config.bucketName = 'nhsbsa-pro-fs-fileservice';
      config.apiKey = 'GLljiARTab5oPW03zcVo618xEM1Ms1l5fzRQ16Y5';
      
  } 
  karate.configure('connectTimeout', 5000);
  karate.configure('readTimeout', 5000);
  return config;
}
