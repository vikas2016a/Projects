# File Upload Service API tests
Note: In absence of dev/test if you want to run it locally you need to clone/copy the development code and make it running-

## Description

## Setup

* Maven should be installed
* clone/copy project
* To run it locally: first clone/copy all development project  and run it


## Running tests

* cd to project folder

For Full test of File Upload Service on local environment
* run `mvn clean test -Dkarate.env="local"`

For Regression test of File Upload Service on test environment
* run `mvn clean test -Dkarate.env="tst" -Dcucumber.options=" --tags @Pack"`

For Smoke test of File Upload Service on test environment
* run `mvn clean test -Dkarate.env="tst" -Dcucumber.options=" --tags @smokeTest"`


